# -*- coding: utf-8 -*-
# Author: cache-sk
# Created on: 19.12.2021
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import xbmcgui
import xbmcplugin

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode

from utils import setup_adaptive

CHANNELS = {
    'fashion':'http://lb.streaming.sk/fashiontv/stream/playlist.m3u8',
    'doktor':'https://live.tvdoktor.sk/high/index.m3u8',
    'szts':'https://dash2.antik.sk/live/tanecnesutaze/index.m3u8'
}

HEADERS={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36','referer':'http://live.streaming.sk/'}

def play(_handle, _addon, params):
    channel = params['channel']
    if not channel in CHANNELS:
        raise #TODO

    uheaders = urlencode(HEADERS)

    li = xbmcgui.ListItem(path=CHANNELS[channel])
    setup_adaptive(li, None, 'hls')
    xbmcplugin.setResolvedUrl(_handle, True, li)


