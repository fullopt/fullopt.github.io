<?php
$page = file_get_contents($_GET["url"]);
echo $page;
?>